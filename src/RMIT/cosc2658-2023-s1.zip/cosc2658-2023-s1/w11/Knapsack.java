package w11;

public class Knapsack {
    class SubSetGenerator {
        static boolean[] selected;
        static double subset(double A, double[] w, double[] s, int index) {
            if (A == 0 || index == 0) {
                return 0;
            }

            if (s[index - 1] > A) {
                return subset(A, w, s, index - 1);
            }

            double case1 = w[index - 1] + subset(A - s[index - 1], w, s, index - 1);
            double case2 = subset(A, w, s, index - 1);

            if (case1 > case2) {
                selected[index - 1] = true;
                return case1;
            } else {
                return case2;
            }
        }
    }
}
