package test1_real;

import w03.LinkedListStack;

public class DiamondBox {
  private String config;

  public DiamondBox(String c) {
    config = c;
  }

  // isValid complexity = O(N)
  public boolean isValid() {
    LinkedListStack<Character> stack = new LinkedListStack<>();
    for (int i = 0; i < config.length(); i++) {
      char letter = config.charAt(i);
      if (letter == '[') {
        stack.push(letter);
        continue;
      }
      if (letter == ']') {
        if (stack.isEmpty()) {
          // found a close bracket without an openning one
          return false;
        }
        // don't need to compare '[' and ']' because
        // we push the letter '[' only
        stack.pop();
        if (stack.isEmpty() && i < config.length() - 1) {
          // found the close bracket of the outer-most box
          // but still have some letters to check
          return false;
        }
        continue;
      }
      // at this point, letter must be '*'
      if (stack.isEmpty()) {
        // found a diamond outside of all boxes
        return false;
      }
    }
    return true;
  }

  // deepestLevel complexity = O(N)
  public int deepestLevel() {
    LinkedListStack<Character> stack = new LinkedListStack<>();
    int maxLevel = 0;
    for (int i = 0; i < config.length(); i++) {
      char letter = config.charAt(i);
      if (letter == '[') {
        stack.push(letter);
        maxLevel = Math.max(maxLevel, stack.size());
        continue;
      }
      if (letter == ']') {
        stack.pop();
      }
    }
    return maxLevel;
  }

  // maxDiamonds complexity = O(N)
  // idea: use a stack of counter values
  // at any point, we count the diamonds in the
  // top element of the stack only
  public int maxDiamonds() {
    int maxValue = 0;
    LinkedListStack<Integer> stack = new LinkedListStack<>();
    for (int i = 0; i < config.length(); i++) {
      if (config.charAt(i) == '[') {
        stack.push(0);
        continue;
      }
      if (config.charAt(i) == ']') {
        stack.pop();
        continue;
      }
      // find one more diamond
      int current = stack.peek();
      stack.pop();
      stack.push(current + 1);
      maxValue = Math.max(maxValue, current + 1);
    }
    return maxValue;
  }

  public static void main(String[] args) {
    String[] testCases = {"[]", "[**[****]*]", "[[[][***[****]**]]]", "[][]", "[]*", "*[]"};
    for (int t = 0; t < testCases.length; t++) {
      System.out.println(testCases[t]);
      DiamondBox box = new DiamondBox(testCases[t]);
      boolean valid = box.isValid();
      if (valid) {
        System.out.println("Valid");
        System.out.println(box.deepestLevel());
        System.out.println(box.maxDiamonds());
      } else {
        System.out.println("Invalid");
      }
      System.out.println();
    }
  }
}
