package test1_real;

import w03.LinkedListQueue;

public class JunctionMap {
  private int[][] junctions;
  private int size;

  public JunctionMap(int[][] input) {
    junctions = input;
    size = input.length;
  }

  // hasOneWayStreet complexity = O(N^2)
  public boolean hasOneWayStreet() {
    // if there is at least one pair(i, j) such that
    // junctions[i][j] != junctions[i][j]
    // this map contains a one-way street
    for (int i = 0; i < size; i++) {
      for (int j = 0; j < size; j++) {
        if (junctions[i][j] != junctions[j][i]) {
          return true;
        }
      }
    }
    return false;
  }

  // hasDeadEnd complexity = O(N^2)
  public boolean hasDeadEnd() {
    // if there is at least one row i-th such that
    // junctions[i][j] = 0 for every j
    // this row i-th is a deadend
    for (int i = 0; i < size; i++) {
      int total = 0;
      for (int j = 0; j < size; j++) {
        total += junctions[i][j];
      }
      if (total == 0) {
        return true;
      }
    }
    return false;
  }

  // getShortestPath complexity = O(N^2)
  public String getShortestPath(int src, int dest) {
    // use BFS (week 4, problem 3)
    // visited states
    boolean[] visited = new boolean[size];
    for (int i = 0; i < size; i++) {
      visited[i] = false;
    }

    // if we go to node j from node i
    // store parent[j] = i
    // to construct the traversed path
    int[] parent = new int[size];
    for (int i = 0; i < size; i++) {
      parent[i] = -1;
      // parent[i] = -1 mean there is no 
      // parent for node i-th currently
    }
    
    // to enqueue a node, we just need the node index
    LinkedListQueue<Integer> queue = new LinkedListQueue<>();

    // start from node src
    queue.enQueue(src);
    visited[src] = true;

    while (!queue.isEmpty()) {
      int nodeIdx = queue.peekFront();
      queue.deQqueue();

      // if this is the target, we can stop now
      if (nodeIdx == dest) {
        StringBuilder sb = new StringBuilder();
        sb.insert(0, nodeIdx);
        while (parent[nodeIdx] != -1) {
          nodeIdx = parent[nodeIdx];
          sb.insert(0, nodeIdx + " -> ");
        }
        return sb.toString();
      }

      //source_index -> intermediate_index1 -> intermediate_index2 ... -> destination_index

      // add all adjacent nodes to the queue
      for (int i = 0; i < size; i++) {
        if (junctions[nodeIdx][i] == 1 && !visited[i]) {
          queue.enQueue(i);
          visited[i] = true;
          // we go to i-th from nodeIdx
          // => nodeIdx must be "parent" of i-th
          parent[i] = nodeIdx;
        }
      }
    }
    // if we reach this point, we cannot go to
    // any further junctions, but we still do not reach
    // destination, so return an emtpy String
    return "";
  }

  public static void main(String[] args) {
    JunctionMap map = new JunctionMap(new int[][]{
      {0, 1, 0, 1, 0, 0},
      {0, 0, 1, 0, 0, 0},
      {0, 0, 0, 1, 0, 0},
      {0, 0, 0, 0, 1, 1},
      {0, 0, 0, 0, 0, 1},
      {0, 0, 0, 0, 0, 0}
    });
    System.out.println(map.hasOneWayStreet());
    System.out.println(map.hasDeadEnd());
    System.out.println(map.getShortestPath(0, 1));
    // 0 -> 1
    System.out.println(map.getShortestPath(0, 2));
    // 0 -> 1 -> 2
    System.out.println(map.getShortestPath(0, 4));
    // 0 -> 3 -> 4
    System.out.println(map.getShortestPath(0, 5));
    // 0 -> 3 -> 5    
    System.out.println(map.getShortestPath(1, 0));
    // empty
  }
}
