package test2_sample;

public class TriEasyLearning {
  int[][] switchingCost;
  int N;

  public static void main(String[] args) {
    TriEasyLearning learn = new TriEasyLearning(new int[][] {
      {0, 1, 5},
      {4, 0, 3},
      {2, 1, 0}
    });
    System.out.println(learn.directSequence());  // expected: 5
    System.out.println(learn.compare(new int[] {0, 2}, new int[] {0, 1, 2}));  // expected: 1
    System.out.println(learn.bestSequence());  // expected: 4
  }

  public TriEasyLearning(int[][] A) {
    switchingCost = A;
    N = switchingCost.length;
  }

  // directSequence complexity = O(1)
  public int directSequence() {
    return switchingCost[0][N - 1];
  }

  // compare complexity = O(N)
  public int compare(int[] seq1, int[] seq2) {
    int cost1 = 0;
    int cost2 = 0;
    for (int i = 0; i < seq1.length - 1; i++) {
      cost1 += switchingCost[seq1[i]][seq1[i + 1]];
    }
    for (int i = 0; i < seq2.length - 1; i++) {
      cost2 += switchingCost[seq2[i]][seq2[i + 1]];
    }
    if (cost1 > cost2) {
      return 1;
    }
    if (cost1 < cost2) {
      return -1;
    }
    return 0;
  }

  // bestSequence complexity = O(N^2)
  public int bestSequence() {
    // this is the shortest path problem
    // use Dijkstra algo to solve it

    int src = 0;
    int dest = N - 1;
     
    int[] distances = new int[N];
    boolean[] visited = new boolean[N];
    int[] previous = new int[N];
  
    for (int i = 0; i < N; i++) {
      distances[i] = Integer.MAX_VALUE;
      previous[i] = -1;
    }
    distances[src] = 0;
  
    while (true) {
      // Greedy choice: retrieve the shortest-distance node from
      // unvisited nodes
      int shortest = Integer.MAX_VALUE;
      int shortestNode = -1;
      for (int i = 0; i < N; i++) {
        if (visited[i]) {
          continue;
        }
        if (shortest > distances[i]) {
          shortest = distances[i];
          shortestNode = i;
        }
      }

       // update the shortest distance through shortest node
      // to all unvisited nodes
      for (int i = 0; i < N; i++) {
        if (visited[i]) {
          continue;
        }
        // shortestNode and i are connected?
        if (switchingCost[shortestNode][i] > 0) {
          // current distance to i > distance reached through shortestNode
          if (distances[i] > distances[shortestNode] + switchingCost[shortestNode][i]) {
            distances[i] = distances[shortestNode] + switchingCost[shortestNode][i];
            previous[i] = shortestNode;
          }
        }
      }

      if (shortestNode == dest) {
        // we reach the destination
        // display the shortest path
        String path = shortestNode + "";
        while (previous[shortestNode] != -1) {
          shortestNode = previous[shortestNode];
          path = shortestNode + " -> " + path;
        }
        System.out.println("Shortest path: " + path);
        return distances[dest];
      }

      // even shortest is INFINITY => stop
      if (shortest == Integer.MAX_VALUE) {
        // we cannot go further
        return Integer.MAX_VALUE;
      }

      // continue the next round
      visited[shortestNode] = true;
    }
  }
}
