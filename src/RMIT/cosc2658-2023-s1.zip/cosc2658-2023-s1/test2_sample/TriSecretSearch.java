package test2_sample;

public class TriSecretSearch {
  double XA;
  double YA;
  double VA;
  double XB;
  double YB;
  double VB;

  public TriSecretSearch(double XA, double YA, double VA, double XB, double YB, double VB) {
    this.XA = XA;
    this.YA = YA;
    this.VA = VA;
    this.XB = XB;
    this.YB = YB;
    this.VB = VB;
  }

  // complexity = O(1)
  public double minTimeA() {
    return Math.abs(YA) / VA;
  }

  private double distance(double x1, double y1, double x2, double y2) {
    return Math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
  }

  // complexity = O(1)
  public double timeFromA(double XZ) {
    double di = distance(XA, YA, XZ, 0);
    return di / VA;
  }

  private double timeFromB(double XZ) {
    double di = distance(XB, YB, XZ, 0);
    return di / VB;
  }
  
  // complexity = O(lg(N)) where N = (XB - XA) / precision
  public double pointC() {
    double epsilon = 0.000001;
    double minC = XA;
    double maxC = XB;

    while (maxC - minC > epsilon) {
      double midC = (minC + maxC) / 2;
      double tA = timeFromA(midC);
      double tB = timeFromB(midC);
      if (tA < tB) {
        minC = midC;
      } else {
        maxC = midC;
      }
    }
    return minC;
  }

  public static void main(String[] args) {
    TriSecretSearch search = new TriSecretSearch(-1, 1, 1, 1, -1, 0.5);
    System.out.printf("%.6f\n", search.minTimeA());
    System.out.printf("%.6f\n", search.timeFromA(0));
    System.out.printf("%.6f\n", search.pointC());
  }
}
