package test2_sample;

public class TriDoraemonCake {
  TriTopic[] topics;
  double A;

  public TriDoraemonCake(TriTopic[] topics, double A) {
    this.topics = topics;
    this.A = A;
  }

  public static void main(String[] args) {
    TriDoraemonCake cake = new TriDoraemonCake(new TriTopic[]
      {
        new TriTopic(8.0, 7.0),
        new TriTopic(10.0, 8.0),
        new TriTopic(5.0, 3.0),
      },
      10.0
    );
    System.out.println(cake.unlimitedCake());  // expected: 23.0
    System.out.println(cake.weightByNumber(2));  // expected: 18.0
    System.out.println(cake.largestWeight());  // expected: 13.0
  }

  // complexity = O(N)
  public double unlimitedCake() {
    double res = 0;
    for (int i = 0; i < topics.length; i++) {
      res += topics[i].W;
    }
    return res;
  }

  // complexity O(N*lg(N))
  public double weightByNumber(int X) {
    double[] v = new double[topics.length];
    for (int i = 0; i < topics.length; i++) {
      v[i] = topics[i].W;
    }
    // sort
    MergeSort sort = new MergeSort();
    sort.mergeSort(v);
    double res = 0;
    for (int i = topics.length - 1; i >= topics.length - X; i--) {
      res += v[i];
    }
    return res;
  }

  // complexity = O(2^N)
  public double largestWeight() {
    int n = topics.length;
    boolean[] selected = new boolean[n];
    for (int i = 0; i < n; i++) {
      selected[i] = false;
    }
    TopicSubSet.A = A;
    TopicSubSet.subset(topics, selected, 0);
    // construct the subset
    String res = "";
    for (int i = 0; i < n; i++) {
      if (TopicSubSet.bestSelection[i]) {
        res = res + " " + i;
      }
    }
    System.out.println("Best selection:" + res);

    // return largest weight
    return TopicSubSet.largestWeight;
  }  
}

class TriTopic {
  double W;
  double S;

  public TriTopic(double W, double S) {
    this.W = W;
    this.S = S;
  }
}

class MergeSort {
  public void mergeSort(double arr[]) {
    if (arr.length > 1) {
      int n = arr.length;
      int middle = n / 2;

      // create 2 sub-arrays from arr
      double[] sub1 = new double[middle];
      for (int i = 0; i < middle; i++) {
        sub1[i] = arr[i];
      }
      double[] sub2 = new double[n - middle];
      for (int i = middle; i < n; i++) {
        sub2[i - middle] = arr[i];
      }

      // sort first and second halves
      mergeSort(sub1);
      mergeSort(sub2);

      // merge sub1 and sub2 into the original array
      merge(sub1, sub2, arr);
    }
  }

  // merge two sub-arrays sub1 and sub2 into the array dest
  public void merge(double[] sub1, double[] sub2, double[] dest) {
    int p1 = 0, p2 = 0, pDest = 0;  // pointers to 3 arrays
    while (p1 < sub1.length && p2 < sub2.length) {
      if (sub1[p1] <= sub2[p2]) {
        dest[pDest] = sub1[p1];
        p1++;
      } else {
        dest[pDest] = sub2[p2];
        p2++;
      }
      pDest++;
    }

    // copy remaining elements, if any
    while (p1 < sub1.length) {
      dest[pDest++] = sub1[p1++];
    }
    while (p2 < sub2.length) {
      dest[pDest++] = sub2[p2++];
    }
  }
}

// copy from week 6's code
class TopicSubSet {
  // best selection and largest weight
  static boolean[] bestSelection;
  static double largestWeight = 0;
  static double A = 0;

  static void subset(TriTopic[] input, boolean[] selected, int idx) {
    if (idx == input.length) {
      process(input, selected);
      return;
    }

    // Not selected
    selected[idx] = false;
    subset(input, selected, idx + 1);

    // Selected
    selected[idx] = true;
    subset(input, selected, idx + 1);
  }

  static void process(TriTopic[] set, boolean[] selected) {
    double w = 0;  // total weight
    double s = 0;  // total printed surface
    for (int i = 0; i < set.length; i++) {
      if (selected[i]) {
        w += set[i].W;
        s += set[i].S;
      }
    }
    // total printed surface area <= cake area A?
    if (s <= A) {
      if (w > largestWeight) {
        largestWeight = w;
        bestSelection = selected.clone();
      }
    }
  }
}